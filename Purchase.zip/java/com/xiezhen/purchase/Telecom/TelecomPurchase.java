package com.xiezhen.purchase.Telecom;

import android.util.Log;
import cn.game189.sms.SMS;
import cn.game189.sms.SMSListener;

import com.xiezhen.MyGameActivity;
import com.xiezhen.ThirdpartyPurchaseDriver;

class TelecomPurchase extends ThirdpartyPurchaseDriver {
	public native void FirePaymentComplete( long nativeObject, int resultCode );
	
	public TelecomPurchase( long nativeDriverPtr ) {
		super(nativeDriverPtr);
	}

	class PurchaseCallBack implements SMSListener {
		public void smsOK(String feeName) {
			Log.v("TelecomPurchase", "free of["+feeName+"] successsed.");
			FirePaymentComplete(mNativeDriverPtr, ThirdpartyPurchaseDriver.BILLING_RESULT_SUCCESS);
		}
		
		public void smsFail(String feeName, int errorCode) {
			Log.e("TelecomPurchase", "failed! free of:["+feeName+"] errorCode:"+errorCode);
			FirePaymentComplete(mNativeDriverPtr, ThirdpartyPurchaseDriver.BILLING_RESULT_FAILED);
		}

		public void smsCancel(String feeName, int errorCode) {
			Log.v("TelecomPurchase", "Canceled! free of:["+feeName+"] errorCode:"+errorCode);
			FirePaymentComplete(mNativeDriverPtr, ThirdpartyPurchaseDriver.BILLING_RESULT_CANCELED);
		}
	}
	
	public void RequestPay(final String name, final String code, final String tips, final String okInfo) {
		Log.v("TelecomPurchase", "RequestPay( name: " + name + " + code: " + code + " tips: " + tips + "okInfo: " + okInfo + " )");
		if (SMS.checkFee(name, MyGameActivity.instance()
				,new PurchaseCallBack(), code, tips, okInfo)) {
			FirePaymentComplete(mNativeDriverPtr, ThirdpartyPurchaseDriver.BILLING_RESULT_ALREADY_PAID);
		}
	}
}