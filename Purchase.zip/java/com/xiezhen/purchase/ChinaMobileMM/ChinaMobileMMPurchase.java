package com.xiezhen.purchase.ChinaMobileMM;

import java.util.HashMap;

import mm.purchasesdk.OnPurchaseListener;
import mm.purchasesdk.Purchase;
import mm.purchasesdk.PurchaseCode;
import android.util.Log;

import com.xiezhen.MyGameActivity;
import com.xiezhen.ThirdpartyPurchaseDriver;

class ChinaMobileMMPurchase extends ThirdpartyPurchaseDriver {
	public native void FirePaymentComplete( long nativeObject, int resultCode );
	
	public ChinaMobileMMPurchase( long nativeDriverPtr ) {
		super(nativeDriverPtr);
	}
	
	class PurchaseListener implements OnPurchaseListener {
		
		/**
		 * 申请安全凭证流程结束之后，此接口被调用。
		 */
		@Override
		public void onAfterApply() {
			
		}

		/**
		 * 申请版权文件流程结束之后 ，此接口被调用
		 */
		@Override
		public void onAfterDownload() {
			
		}

		/**
		 * 申请安全凭证流程之前，此接口被调用
		 */
		@Override
		public void onBeforeApply() {
			
		}

		/**
		 * 申请版权文件流程之前，此接口被调用
		 */
		@Override
		public void onBeforeDownload() {
			
		}

		/**
		 * 订购接口被调用，当此次订购流程结束时，自动被IAP组件调用，告知APP和用户订购结果
		 */
		@Override
		public void onBillingFinish(int code, HashMap arg1) {
			Log.v("ChinaMobileMMPurchase", "onBillingFinish " + code);
			if (arg1 != null) {
				Log.v("ChinaMobileMM_PurchaseListener", "HashMap( " +
						"LEFTDAY: " + (String)arg1.get(OnPurchaseListener.LEFTDAY) +
						"ORDERID: " + (String)arg1.get(OnPurchaseListener.LEFTDAY) +
						"PAYCODE: " + (String)arg1.get(OnPurchaseListener.PAYCODE) +
						"TRADEID: " + (String)arg1.get(OnPurchaseListener.TRADEID) +" )");
			}
			
			if (code == PurchaseCode.ORDER_OK || (code == PurchaseCode.AUTH_OK)) {
				FirePaymentComplete(mNativeDriverPtr, ThirdpartyPurchaseDriver.BILLING_RESULT_SUCCESS);
			} else {
				FirePaymentComplete(mNativeDriverPtr, ThirdpartyPurchaseDriver.BILLING_RESULT_FAILED);
			}
		}

		@Override
		public void onInitFinish(int code) {
			Log.v("ChinaMobileMMPurchase", "Init finish, status code = " + code);
		}

		@Override
		public void onQueryFinish(int code, HashMap arg1) {
			Log.v("ChinaMobileMMPurchase", "query finish, status code = " + code);
		}
	}
	
	
	private PurchaseListener mChinaMobileMMListener = null;
	private mm.purchasesdk.Purchase mChinaMobilePurchase = null;
	private static final String ChinaMobileMM_APPID = "300002780468";
	private static final String ChinaMobileMM_APPKEY = "28D791CBC2396852";
	
	class InitRunnable implements Runnable
    {
        public void run()
        {
        	mChinaMobileMMListener = new PurchaseListener();
        	mChinaMobilePurchase = Purchase.getInstance(); 
        	
			try {
				mChinaMobilePurchase.setAppInfo(ChinaMobileMM_APPID, ChinaMobileMM_APPKEY);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			try {
				mChinaMobilePurchase.init(MyGameActivity.instance(), mChinaMobileMMListener);
			} catch (Exception e) {
				e.printStackTrace();
			}

        }
    }
	
	class LoaderThread extends Thread {
		public void run()
		{ 	
			MyGameActivity.instance().runOnUiThread(new InitRunnable());
		}
	}
	
	public void InitializeSDK() {
		Log.v("ChinaMobileMMPurchase", "ChinaMobileMM_InitializeSDK");
		LoaderThread t = new LoaderThread();
		t.start(); 
	}
	
	public void RequestPay(final String payCode) {
		MyGameActivity.instance().runOnUiThread(new Runnable() {
			public void run() {
				Log.i("ChinaMobileMMPurchase", "Run Bill Thread");		
				/**
				 * 商品购买接口。checkAndOrder(java.lang.String payCode, int orderCount, OnPurchaseListener listener) 
				 */
				 
				if(mChinaMobileMMListener == null || mChinaMobilePurchase == null)
				{
					Log.v("ChinaMobileMM", "in ChinaMobileMM_DoBilling, find some thing wrong early in ChinaMobileMM_SdkInitialize");
					return;
				}
				
				try {
					mChinaMobilePurchase.order(MyGameActivity.instance(), payCode, mChinaMobileMMListener);

				} catch (Exception e1) {
					//
					e1.printStackTrace();
				}
			}
		});
	}
}