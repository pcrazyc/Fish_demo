package com.xiezhen.purchase.QQGameCenter;

import android.util.Log;

import com.xiezhen.MyGameActivity;
import com.tencent.webnet.PreSMSReturn;
import com.tencent.webnet.WebNetInterface;
import com.xiezhen.ThirdpartyPurchaseDriver;

class QQGameCenterPurchase extends ThirdpartyPurchaseDriver {
	private int mQQGameCenterCode = -1;
	
	public native void FirePaymentComplete( long nativeObject, int resultCode );
	
	public QQGameCenterPurchase( long nativeDriverPtr ) {
		super(nativeDriverPtr);
	}

	
	class GameToHallBroadcast {
		//游戏消息通知Action
		public static final String GAME_NOTIFICATION_ACTION = "com.tencent.qqgame.gamenotification";
		
		//登录成功广播消息ID key
		public static final String KEY_ID = "KEY_ID";
		
		//广播消息登录账号key
		public static final String KEY_LOGIN_ACCOUNT = "KEY_LOGIN_ACCOUNT";
		//广播消息登录密码key
		public static final String KEY_LOGIN_PWD = "KEY_LOGIN_PWD";
		
		//广播消息登保存密码状态key
		public static final String KEY_SAVE_PWD = "KEY_SAVE_PWD";
		//广播消息登保存密码状态key
		public static final String KEY_AUTO_LOGIN = "KEY_AUTO_LOGIN";
		
		//游戏ID Key
		public static final String KEY_GAME_ID = "KEY_GAME_ID";
		
		//登录成功广播ID
		public static final int BROADCAST_ID_LOGIN_SUCCESS = 1;
		//更改登录状态广播ID
		public static final int BROADCAST_ID_CHANGE_LOGIN_STATUS = 2;
		//启动游戏成功
		public static final int BROADCAST_ID_START_SUCCESS = 3;
	}
	
	 class NetEvent implements com.tencent.webnet.WebNetEvent {   	
    	/** SMSBillingPoint call back*/
    	public boolean SendSMSCB(int event, String mark)
    	{
    		if (event == SendSMS_Event_OK) {
    			FirePaymentComplete(mNativeDriverPtr, ThirdpartyPurchaseDriver.BILLING_RESULT_SUCCESS);
    		} else {
    			FirePaymentComplete(mNativeDriverPtr, ThirdpartyPurchaseDriver.BILLING_RESULT_FAILED);
    		}
    		return true;//or false  SDK don't care
    	}
    }
	
	//NetEvent mNetEvent = null;
	static final int QQGameCneter_KeyGameID = 10032;
	
	public void InitializeSDK() {
		Log.v("QQGameCenterPurchase", "InitializeSDK");
	    WebNetInterface.Init(MyGameActivity.instance(), new NetEvent());
		
//		Intent i = new Intent(GameToHallBroadcast.GAME_NOTIFICATION_ACTION);
//		i.putExtra(GameToHallBroadcast.KEY_ID, GameToHallBroadcast.BROADCAST_ID_START_SUCCESS);
//		i.putExtra(GameToHallBroadcast.KEY_GAME_ID, QQGameCneter_KeyGameID);
//		MyGameActivity.instance().getApplicationContext().sendBroadcast(i);
	}
	
	public void Resume() {
		WebNetInterface.SetCurActivity(MyGameActivity.instance());
	}
	
	public void Destroy() {
		WebNetInterface.Destroy();
	}
	
	public String PrePay(int code) {
		Log.v("QQGameCenterPurchase", "PrePay( " + code + " )");
		mQQGameCenterCode = code;		
		PreSMSReturn rs = WebNetInterface.PreSMSBillingPoint(code);
		Log.v("ThirdpartyPurchaseDriver", "m_contents: " + rs.m_contents + ", m_bSuccess: " + (rs.m_bSuccess ? "true" : "false"));
		
		if (!rs.m_bSuccess) return "";
		return rs.m_contents;
	}
	
	public void RequestPay(int code) {
		Log.v("QQGameCenterPurchase ", "RequestPay( " + code + " )");
		if(code != mQQGameCenterCode) {	
			Log.d("ThirdpartyPurchaseDriver", "error: code(" + code + ") is unmatch with mQQGameCenterCode(" + mQQGameCenterCode + ")");
			FirePaymentComplete(mNativeDriverPtr, ThirdpartyPurchaseDriver.BILLING_RESULT_FAILED);
		} else {
			if (!MyGameActivity.instance().isFinishing()) {
				//MyGameActivity.instance().runOnUiThread(m_ShowPayConfirmDialog);
				//do not show dialog, for dialog will kick pvz to suspend status
				WebNetInterface.SMSBillingPoint(mQQGameCenterCode, mQQGameCenterCode + " " + System.currentTimeMillis());
			}
		}
	}
}