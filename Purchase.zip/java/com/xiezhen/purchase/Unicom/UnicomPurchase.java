package com.xiezhen.purchase.Unicom;

import android.util.Log;

import com.xiezhen.MyGameActivity;
import com.xiezhen.ThirdpartyPurchaseDriver;

import com.multimode_billing_sms.ui.MultiModePay;

class UnicomPurchase extends ThirdpartyPurchaseDriver {
	
	public native void FirePaymentComplete( long nativeObject, int resultCode );
	
	public UnicomPurchase( long nativeDriverPtr ) {
		super(nativeDriverPtr);
	}
	
	class PurchaseCallBack implements MultiModePay.SMSCallBack {
		public void ButtonCLick(int flag) {  //界面按钮点击回调
			
		}

		public void SmsResult(int result, String desc) {  //支付结果回调
			Log.v( "UnicomPurchase", "SmsResult( " + result + ", " + desc + " )" );
			if(result == MultiModePay.SUCCESS || result == MultiModePay.TIMEOUT ) {   //如果是短信发送成功或者延时超过指定时间，都设置为成功，发放道具
				FirePaymentComplete(mNativeDriverPtr, ThirdpartyPurchaseDriver.BILLING_RESULT_SUCCESS);
			} else if (result == MultiModePay.FAILD) {
				FirePaymentComplete(mNativeDriverPtr, ThirdpartyPurchaseDriver.BILLING_RESULT_FAILED);
			} else if ( result == MultiModePay.CANCEL ) {
				FirePaymentComplete(mNativeDriverPtr, ThirdpartyPurchaseDriver.BILLING_RESULT_CANCELED);
			}
			
			MultiModePay.getInstance().DismissProgressDialog(); //取消进度条,此行必须有才能回到游戏界面
		}
	}

	public void RequestPay( final String name, final String money, final String code ) {
		Log.v( "UnicomPurchase", "RequestPay( " + name + ", " + money + ", " + code + " )" );
		MyGameActivity.instance().runOnUiThread(new Runnable() {
		    public void run() {
		    	MultiModePay.getInstance().setEnableSend(true);
		    	MultiModePay.getInstance().sms( MyGameActivity.instance()
		    			,"company","phone number","app name", name, money, code
		    			,new PurchaseCallBack() );
		    }
		});
	}
}

