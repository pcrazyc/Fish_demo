package com.xiezhen.purchase.ChinaMobile;

import android.util.Log;
import cn.emagsoftware.gamebilling.api.GameInterface;

import com.xiezhen.MyGameActivity;
import com.xiezhen.ThirdpartyPurchaseDriver;


class ChinaMobilePurchase extends ThirdpartyPurchaseDriver {
	public native void FirePaymentComplete( long nativeObject, int resultCode );
	
	public ChinaMobilePurchase( long nativeDriverPtr ) {
		super(nativeDriverPtr);
	}
	
	class PurchaseCallBack implements GameInterface.BillingCallback {
		@Override
		public void onBillingSuccess() {
			Log.v("ChinaMobilePurchase", "onBillingSuccess()");
			FirePaymentComplete(mNativeDriverPtr, ThirdpartyPurchaseDriver.BILLING_RESULT_SUCCESS);
		}

		@Override
		public void onBillingFail() {
			Log.e("ChinaMobilePurchase", "onBillingFail()");
			FirePaymentComplete(mNativeDriverPtr, ThirdpartyPurchaseDriver.BILLING_RESULT_FAILED);
		}

		@Override
		public void onUserOperCancel() {
			Log.v("ChinaMobilePurchase", "onUserOperCancel()");
			FirePaymentComplete(mNativeDriverPtr, ThirdpartyPurchaseDriver.BILLING_RESULT_CANCELED);
		}
	}
	
	public void InitializeSDK() {
		Log.v("ChinaMobilePurchase", "ChinaMobile_InitializeSDK");
		GameInterface.initializeApp(MyGameActivity.instance(), "PlantsVsZombies Endless", "Popcap Games", "");
	}
	
	public void RequestPay(final String code) {
		Log.v("ChinaMobilePurchase", "ChinaMobile_RequestPay( " + code + " )");
		
		if(GameInterface.getActivateFlag(code)){
			Log.w("ChinaMobilePurchase", "already paid! code:[" + code + "]");
			FirePaymentComplete(mNativeDriverPtr, ThirdpartyPurchaseDriver.BILLING_RESULT_ALREADY_PAID);
			return;
		}

		GameInterface.doBilling(true, true, code, new PurchaseCallBack());
	}
}
	