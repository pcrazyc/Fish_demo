#include "PurchaseBroker.h"
#ifdef HOST_IPHONEOS
#include "drivers/purchase/ios/IOSPurchaseDriver.h"
#endif
#include "StructuredData.h"
#include "LawnApp.h"
#include "ProfileMgr.h"
#include "ServerConfig.h"
#include "TodStringFile.h"
#include "PurchaseItemWidget.h"

PurchaseBroker::PurchaseBroker()
{
    m_purchaseState = PURCHASESTATE_None;
	m_purchaseDriver = IPurchaseDriver::CreatePurchaseDriver();
    m_purchaseDriver->SetPaymentMonitor(this);
}

PurchaseBroker::~PurchaseBroker()
{
}

void PurchaseBroker::RequestPayment(const std::string& product_id)
{
    if (gCheats->GetToggleValue("FakePurchaseLoop"))
    {
        //TODO Implementation
    }
    else
    {
        //TODO Implementation
    }
}

void PurchaseBroker::ConfirmDelivery(const std::string& product_id)
{
    m_purchaseDriver->ConfirmDelivery(product_id);
}

void PurchaseBroker::Refresh(const StructuredData* productIds, IPurchaseDriver::RefreshCallback callback)
{
    m_purchaseDriver->Refresh(productIds, callback);
}

void PurchaseBroker::Update()
{
    if (m_purchaseState == PURCHASESTATE_NeedToSendPurchase)
    {
        m_purchaseState = PURCHASESTATE_WaitingForResponse;
        m_purchaseDriver->RequestPayment(m_requestedSku);
    }
}

void PurchaseBroker::PurchaseDriverPaymentComplete(IPurchaseDriver* merch, const std::string& receiptId, const std::string& receipt)
{
    //TODO Implementation VerifyReceipt
}

void PurchaseBroker::PurchaseDriverPaymentIncomplete(IPurchaseDriver* merch, const std::string& productId, IPurchaseDriver::CauseForIncompletion incomplete_cause)
{
    // just exit out early because we don't care that they pressed cancel
    if(incomplete_cause == IPurchaseDriver::Canceled || m_purchaseState != PURCHASESTATE_WaitingForResponse)
    {
        m_purchaseState = PURCHASESTATE_None;
        return;
    }

    //TODO Implementation
}

void PurchaseBroker::ServiceRequestCompleted(const StructuredData* response, const void* context)
{
    if (m_purchaseState != PURCHASESTATE_WaitingForResponse)
    {
        return;
    }

    //TODO Implementation
}

void PurchaseBroker::ServiceRequestFailed(const StructuredData* response, const void* context)
{
    if (m_purchaseState != PURCHASESTATE_WaitingForResponse)
    {
        return;
    }
	
	//TODO Implementation
}