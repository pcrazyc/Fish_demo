#ifndef PURCHASE_BROKER_H_INCLUDED
#define PURCHASE_BROKER_H_INCLUDED

#include <string>
#include "IPurchaseDriver.h"


enum PurchaseState
{
	PURCHASESTATE_None,
	PURCHASESTATE_NeedToSendPurchase,
	PURCHASESTATE_WaitingForResponse,
};
#ifdef HOST_ANDROID
	#include "drivers/purchase/android/IPurchaseAdapter.h"
#endif

class PurchaseBroker : public IPaymentMonitor
#ifdef HOST_IPHONEOS
      , public NetworkServiceListener
#endif
{
 public:
    PurchaseBroker();
	virtual ~PurchaseBroker();

	void RequestPayment(const std::string& productId);
	void ConfirmDelivery(const std::string& productId);
	void Refresh( const StructuredData* productIds, IPurchaseDriver::RefreshCallback callback );

	//IPaymentMonitor
	virtual void PurchaseDriverPaymentComplete( IPurchaseDriver* merch, const std::string& receiptId, const std::string& receipt );
	virtual void PurchaseDriverPaymentIncomplete( IPurchaseDriver* merch, const std::string& productId, IPurchaseDriver::CauseForIncompletion );

#ifdef HOST_IPHONEOS
	//NetworkServiceListener
	virtual void ServiceRequestCompleted( const StructuredData* response, const void* context );
	virtual void ServiceRequestFailed( const StructuredData* response, const void* context );
#elif defined(HOST_ANDROID)
	void Init();
	IPurchaseAdapter* CreatePurchaseAdapter();
#endif
	
public:
	IPurchaseDriver* m_purchaseDriver;
	
private:
	std::string m_requestedSku;
	
};

#endif
