#include "UnicomPurchaseAdapter.h"
#include "ProfileMgr.h"

JavaMethod<void>	UnicomPurchaseAdapter::JavaRequestPay;

UnicomPurchaseAdapter::UnicomPurchaseAdapter() {
	__android_log_print( ANDROID_LOG_INFO, "UnicomPurchase", "Let's get retarded!" );

	JNIEnv* env = Android::Util::GetJNIEnv();
	jlong nativeDriver = reinterpret_cast< jlong >( this );
	ConstructJava( env, "com/popcap/purchase/Unicom/UnicomPurchase", "(J)V", this );
}

UnicomPurchaseAdapter::~UnicomPurchaseAdapter() {

}

void UnicomPurchaseAdapter::BindJavaMethods( JNIEnv* env, const JavaClass& javaClass )
{
	JavaRequestPay		.init( env, javaClass, "RequestPay",	"(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V" );
}

void UnicomPurchaseAdapter::BindNativeMethods( JNIEnv* env, const JavaClass& javaClass )
{
	JNINativeMethod methods[] =
	{
		{"FirePaymentComplete",   "(JI)V", (void*)&UnicomPurchaseAdapter::PaymentHook }
	};
	javaClass.registerNatives( methods, LENGTH(methods) );
}

void UnicomPurchaseAdapter::PaymentHook( JNIEnv* env, jobject javaObject, jlong nativeObject, jint resultCode )
{
	__android_log_print( ANDROID_LOG_VERBOSE, "UnicomPurchase", "PaymentHook( %d )", resultCode );
	std::string strTemp = "";
	IPurchaseAdapter* driver = reinterpret_cast<UnicomPurchaseAdapter*>( nativeObject );
	switch (resultCode) {
	case BILLING_RESULT_SUCCESS:
		AndroidAppDriver::StaticEnqueueCallback( *driver, &IPurchaseAdapter::OnPaymentComplete, strTemp );
		break;
	case BILLING_RESULT_FAILED:
		AndroidAppDriver::StaticEnqueueCallback( *driver, &IPurchaseAdapter::OnPaymentIncomplete, IPurchaseDriver::Error );
		break;
	case BILLING_RESULT_CANCELED:
		AndroidAppDriver::StaticEnqueueCallback( *driver, &IPurchaseAdapter::OnPaymentIncomplete, IPurchaseDriver::Canceled );
		break;
	case BILLING_RESULT_ALREADY_PAID:
		AndroidAppDriver::StaticEnqueueCallback( *driver, &IPurchaseAdapter::OnPaymentIncomplete, IPurchaseDriver::AlreadyPaid );
		break;
	}
}


bool UnicomPurchaseAdapter::CanPay() {
	return true;
}

void UnicomPurchaseAdapter::GetProductCode(const std::string& productId, std::string& productCode) {
	//TODO get code
	productCode = "130121124110";
}

void UnicomPurchaseAdapter::RequestPay(const std::string& productId) {
	IPurchaseAdapter::RequestPay(productId);

	__android_log_print( ANDROID_LOG_VERBOSE, "UnicomPurchase", "RequestPay( %s )", productId.c_str() );
	std::string productCode;
	GetProductCode(productId, productCode);

	JNIEnv* env = Android::Util::GetJNIEnv();
	jstring javaProductName = env->NewStringUTF( "javaProductName" );
	jstring javaProductMoney = env->NewStringUTF( "2" );
	jstring javaProductCode = env->NewStringUTF( productCode.c_str() );

	JavaRequestPay( env, mJavaObject, javaProductName, javaProductMoney, javaProductCode );
	env->DeleteLocalRef( javaProductName );
	env->DeleteLocalRef( javaProductMoney );
	env->DeleteLocalRef( javaProductCode );
}
