#ifndef UNICOMPURCHASEADAPTER_H_INCLUDED
#define UNICOMPURCHASEADAPTER_H_INCLUDED

#include "drivers/purchase/android/IPurchaseAdapter.h"
#include "drivers/app/android/JavaInterface.h"
#include "drivers/app/android/JavaBound.h"
#include "drivers/app/android/AndroidAppDriver.h"

class UnicomPurchaseAdapter : public IPurchaseAdapter, public JavaBound< UnicomPurchaseAdapter > {
public:
	UnicomPurchaseAdapter();
	~UnicomPurchaseAdapter();

	// check system or network if can pay
	virtual bool CanPay();

	// request pay for product
	virtual void RequestPay(const std::string& productId);

	void GetProductCode(const std::string& productId, std::string& productCode);

	static void PaymentHook( JNIEnv* env, jobject javaObject, jlong nativeObject, jint resultCode );
private:
	virtual void BindJavaMethods( JNIEnv* env, const JavaClass& javaClass );
	virtual void BindNativeMethods( JNIEnv* env, const JavaClass& javaClass );

	static JavaMethod<void>	JavaRequestPay;
};

#endif
