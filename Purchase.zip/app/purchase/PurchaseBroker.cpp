#include "PurchaseBroker.h"
#include "LawnApp.h"
#include "Common.h"
#include "UnicomPurchaseAdapter.h"
#include "ChinaMobilePurchaseAdapter.h"
#include "TelecomPurchaseAdapter.h"
#include "ChinaMobileMMPurchaseAdapter.h"
#include "QQGameCenterPurchaseAdapter.h"
#include "IPurchaseDriver.h"
#include "PropertiesParser.h"

PurchaseBroker::PurchaseBroker() {
	m_purchaseDriver = IPurchaseDriver::CreatePurchaseDriver();

#ifdef HOST_ANDROID
	IPurchaseAdapter *purchaseAdapter = CreatePurchaseAdapter();
	if (purchaseAdapter) {
		((AndroidPurchaseDriver *)m_purchaseDriver)->SetPurchaseAdapter(purchaseAdapter);
	}
	m_purchaseDriver->SetPaymentMonitor(this);
#endif
}

PurchaseBroker::~PurchaseBroker() {

}

#ifdef HOST_ANDROID
	void PurchaseBroker::Init() {
		((AndroidPurchaseDriver *)m_purchaseDriver)->Init();
	}

	IPurchaseAdapter* PurchaseBroker::CreatePurchaseAdapter() {
		Buffer aBuffer;
		gLawnApp->ReadBufferFromFile("properties/PurchaseChannel.xml", &aBuffer);

		PropertiesParser aPropertiesParser(gLawnApp);
		if (!aPropertiesParser.ParsePropertiesBuffer(aBuffer))
		{
			return 0;
		}

		bool bUnicomPurchase = gLawnApp->GetBoolean("UnicomPurchase", false);
		bool bTelecomPurchase = gLawnApp->GetBoolean("TelecomPurchase", false);
		bool bChinaMobilePurchase = gLawnApp->GetBoolean("ChinaMobilePurchase", false);
		bool bChinaMobileMMPurchase = gLawnApp->GetBoolean("ChinaMobileMMPurchase", false);
		bool bQQGameCenterPurchase = gLawnApp->GetBoolean("QQGameCenterPurchase", false);
		bool bAllPurchase = gLawnApp->GetBoolean("AllPurchase", false);

		if (bAllPurchase) {
			//TODO detect sim card
		} else if (bUnicomPurchase) {
			return new UnicomPurchaseAdapter();
		} else if (bTelecomPurchase) {
			return new TelecomPurchaseAdapter();
		} else if (bChinaMobilePurchase) {
			return new ChinaMobilePurchaseAdapter();
		} else if (bChinaMobileMMPurchase) {
			return new ChinaMobileMMPurchaseAdapter();
		} else if (bQQGameCenterPurchase) {
			return new QQGameCenterPurchaseAdapter();
		}

		return 0;
	}
#endif

void PurchaseBroker::RequestPayment(const std::string& productId) {
	if (gCheats->GetToggleValue("FakePurchaseLoop")) {
		//TODO Implementation
	} else {
		m_purchaseDriver->RequestPayment(productId);
	}
}

void PurchaseBroker::ConfirmDelivery(const std::string& productId) {
	m_purchaseDriver->ConfirmDelivery(productId);
}

void PurchaseBroker::PurchaseDriverPaymentComplete(IPurchaseDriver* merch,
		const std::string& receiptId, const std::string& receipt) {
	//TODO Implementation pay complete
}

void PurchaseBroker::PurchaseDriverPaymentIncomplete(
		IPurchaseDriver* merch, const std::string& productId,
		IPurchaseDriver::CauseForIncompletion cause) {

	if(cause == IPurchaseDriver::Canceled) {
		return;
	}

	//TODO Implementation show cause info
}
