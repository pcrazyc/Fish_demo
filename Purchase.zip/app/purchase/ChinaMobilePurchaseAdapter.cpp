#include "ChinaMobilePurchaseAdapter.h"

JavaMethod<void>	ChinaMobilePurchaseAdapter::JavaInitializeSDK;
JavaMethod<void>	ChinaMobilePurchaseAdapter::JavaRequestPay;

ChinaMobilePurchaseAdapter::ChinaMobilePurchaseAdapter() {
	__android_log_print( ANDROID_LOG_INFO, "ChinaMobilePurchase", "Let's get retarded!" );

	JNIEnv* env = Android::Util::GetJNIEnv();
	jlong nativeDriver = reinterpret_cast< jlong >( this );
	ConstructJava( env, "com/popcap/purchase/ChinaMobile/ChinaMobilePurchase", "(J)V", this );
}

ChinaMobilePurchaseAdapter::~ChinaMobilePurchaseAdapter() {

}

void ChinaMobilePurchaseAdapter::BindJavaMethods( JNIEnv* env, const JavaClass& javaClass )
{
	JavaInitializeSDK	.init( env, javaClass, "InitializeSDK",	"()V" );
	JavaRequestPay		.init( env, javaClass, "RequestPay",	"(Ljava/lang/String;)V" );
}

void ChinaMobilePurchaseAdapter::BindNativeMethods( JNIEnv* env, const JavaClass& javaClass )
{
	JNINativeMethod methods[] =
	{
		{"FirePaymentComplete",   "(JI)V", (void*)&ChinaMobilePurchaseAdapter::PaymentHook }
	};
	javaClass.registerNatives( methods, LENGTH(methods) );
}

void ChinaMobilePurchaseAdapter::PaymentHook( JNIEnv* env, jobject javaObject, jlong nativeObject, jint resultCode ) {
	__android_log_print( ANDROID_LOG_VERBOSE, "ChinaMobilePurchase", "PaymentHook( %d )", resultCode );
	std::string strTemp = "";
	IPurchaseAdapter* driver = reinterpret_cast<ChinaMobilePurchaseAdapter*>( nativeObject );
	switch (resultCode) {
	case BILLING_RESULT_SUCCESS:
		AndroidAppDriver::StaticEnqueueCallback( *driver, &IPurchaseAdapter::OnPaymentComplete, strTemp );
		break;
	case BILLING_RESULT_FAILED:
		AndroidAppDriver::StaticEnqueueCallback( *driver, &IPurchaseAdapter::OnPaymentIncomplete, IPurchaseDriver::Error );
		break;
	case BILLING_RESULT_CANCELED:
		AndroidAppDriver::StaticEnqueueCallback( *driver, &IPurchaseAdapter::OnPaymentIncomplete, IPurchaseDriver::Canceled );
		break;
	case BILLING_RESULT_ALREADY_PAID:
		AndroidAppDriver::StaticEnqueueCallback( *driver, &IPurchaseAdapter::OnPaymentIncomplete, IPurchaseDriver::AlreadyPaid );
		break;
	}
}

bool ChinaMobilePurchaseAdapter::CanPay() {
	return true;
}

void ChinaMobilePurchaseAdapter::Initialize() {
	IPurchaseAdapter::Initialize();

	__android_log_print( ANDROID_LOG_VERBOSE, "ChinaMobilePurchase", "Initialize" );
	JNIEnv* env = Android::Util::GetJNIEnv();
	JavaInitializeSDK( env, mJavaObject );
}

void ChinaMobilePurchaseAdapter::GetProductCode(const std::string& productId, std::string& productCode) {
	//TODO detail for product
	productCode = "006";
}

void ChinaMobilePurchaseAdapter::RequestPay(const std::string& productId) {
	IPurchaseAdapter::RequestPay(productId);

	__android_log_print( ANDROID_LOG_VERBOSE, "ChinaMobilePurchase", "RequestPay( %s )", productId.c_str() );
	std::string productCode;
	GetProductCode(productId, productCode);

	JNIEnv* env = Android::Util::GetJNIEnv();
	jstring javaProductCode = env->NewStringUTF( productCode.c_str() );
	JavaRequestPay( env, mJavaObject, javaProductCode );
	env->DeleteLocalRef( javaProductCode );
}
