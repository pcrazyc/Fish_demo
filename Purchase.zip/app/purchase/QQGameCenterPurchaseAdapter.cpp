#include "QQGameCenterPurchaseAdapter.h"


JavaMethod<void>	QQGameCenterPurchaseAdapter::JavaInitializeSDK;
JavaMethod<jstring>	QQGameCenterPurchaseAdapter::JavaPrePay;
JavaMethod<void>	QQGameCenterPurchaseAdapter::JavaRequestPay;
JavaMethod<void>	QQGameCenterPurchaseAdapter::JavaResume;
JavaMethod<void>	QQGameCenterPurchaseAdapter::JavaDestroy;

QQGameCenterPurchaseAdapter::QQGameCenterPurchaseAdapter() {
	__android_log_print( ANDROID_LOG_INFO, "QQGameCenterPurchase", "Let's get retarded!" );

	JNIEnv* env = Android::Util::GetJNIEnv();
	jlong nativeDriver = reinterpret_cast< jlong >( this );
	ConstructJava( env, "com/popcap/purchase/QQGameCenter/QQGameCenterPurchase", "(J)V", this );
}

QQGameCenterPurchaseAdapter::~QQGameCenterPurchaseAdapter() {

}

void QQGameCenterPurchaseAdapter::BindJavaMethods( JNIEnv* env, const JavaClass& javaClass )
{
	JavaInitializeSDK	.init( env, javaClass, "InitializeSDK",	"()V" );
	JavaPrePay			.init( env, javaClass, "PrePay",			"(I)Ljava/lang/String;" );
	JavaRequestPay		.init( env, javaClass, "RequestPay",		"(I)V" );
	JavaResume			.init( env, javaClass, "Resume",			"()V" );
	JavaDestroy			.init( env, javaClass, "Destroy",			"()V" );
}

void QQGameCenterPurchaseAdapter::BindNativeMethods( JNIEnv* env, const JavaClass& javaClass )
{
	JNINativeMethod methods[] =
	{
		{"FirePaymentComplete",   "(JI)V", (void*)&QQGameCenterPurchaseAdapter::PaymentHook }
	};
	javaClass.registerNatives( methods, LENGTH(methods) );
}

void QQGameCenterPurchaseAdapter::PaymentHook( JNIEnv* env, jobject javaObject, jlong nativeObject, jint resultCode ) {
	__android_log_print( ANDROID_LOG_VERBOSE, "QQGameCenterPurchase", "PaymentHook( %d )", resultCode );
	std::string strTemp = "";
	IPurchaseAdapter* driver = reinterpret_cast<QQGameCenterPurchaseAdapter*>( nativeObject );
	switch (resultCode) {
	case BILLING_RESULT_SUCCESS:
		AndroidAppDriver::StaticEnqueueCallback( *driver, &IPurchaseAdapter::OnPaymentComplete, strTemp );
		break;
	case BILLING_RESULT_FAILED:
		AndroidAppDriver::StaticEnqueueCallback( *driver, &IPurchaseAdapter::OnPaymentIncomplete, IPurchaseDriver::Error );
		break;
	case BILLING_RESULT_CANCELED:
		AndroidAppDriver::StaticEnqueueCallback( *driver, &IPurchaseAdapter::OnPaymentIncomplete, IPurchaseDriver::Canceled );
		break;
	case BILLING_RESULT_ALREADY_PAID:
		AndroidAppDriver::StaticEnqueueCallback( *driver, &IPurchaseAdapter::OnPaymentIncomplete, IPurchaseDriver::AlreadyPaid );
		break;
	}
}

bool QQGameCenterPurchaseAdapter::CanPay() {
	return true;
}

void QQGameCenterPurchaseAdapter::Initialize() {
	IPurchaseAdapter::Initialize();

	__android_log_print( ANDROID_LOG_VERBOSE, "QQGameCenterPurchase", "Initialize" );
	JNIEnv* env = Android::Util::GetJNIEnv();
	JavaInitializeSDK( env, mJavaObject );
}

void QQGameCenterPurchaseAdapter::GetProductCode(const std::string& productId, int productCode) {
	//TODO get code
	productCode = 1;
}

void QQGameCenterPurchaseAdapter::RequestPay(const std::string& productId) {
	IPurchaseAdapter::RequestPay(productId);

	__android_log_print( ANDROID_LOG_VERBOSE, "QQGameCenterPurchase", "RequestPay( %s )", productId.c_str() );
	int productCode;
	GetProductCode(productId, productCode);
	JNIEnv* env = Android::Util::GetJNIEnv();

	jstring javaPrePurchaseContent = JavaPrePay(env, mJavaObject, productCode);
	std::string prePurchaseContent = JavaString::ToString( env, javaPrePurchaseContent );

	if (prePurchaseContent == "") {
		OnPaymentIncomplete(IPurchaseDriver::Error);
		return;
	}
	//TODO if necessary notify confirm purchase?

	JavaRequestPay( env, mJavaObject, productCode );
}
