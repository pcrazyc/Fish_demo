#include "ChinaMobileMMPurchaseAdapter.h"

JavaMethod<void>	ChinaMobileMMPurchaseAdapter::JavaInitializeSDK;
JavaMethod<void>	ChinaMobileMMPurchaseAdapter::JavaRequestPay;

ChinaMobileMMPurchaseAdapter::ChinaMobileMMPurchaseAdapter() {
	__android_log_print( ANDROID_LOG_INFO, "ChinaMobileMMPurchase", "Let's get retarded!" );

	JNIEnv* env = Android::Util::GetJNIEnv();
	jlong nativeDriver = reinterpret_cast< jlong >( this );
	ConstructJava( env, "com/popcap/purchase/ChinaMobileMM/ChinaMobileMMPurchase", "(J)V", this );
}

ChinaMobileMMPurchaseAdapter::~ChinaMobileMMPurchaseAdapter() {

}

void ChinaMobileMMPurchaseAdapter::BindJavaMethods( JNIEnv* env, const JavaClass& javaClass )
{
	JavaInitializeSDK	.init( env, javaClass, "InitializeSDK",	"()V" );
	JavaRequestPay		.init( env, javaClass, "RequestPay",	"(Ljava/lang/String;)V" );
}

void ChinaMobileMMPurchaseAdapter::BindNativeMethods( JNIEnv* env, const JavaClass& javaClass )
{
	JNINativeMethod methods[] =
	{
		{"FirePaymentComplete",   "(JI)V", (void*)&ChinaMobileMMPurchaseAdapter::PaymentHook }
	};
	javaClass.registerNatives( methods, LENGTH(methods) );
}

void ChinaMobileMMPurchaseAdapter::PaymentHook( JNIEnv* env, jobject javaObject, jlong nativeObject, jint resultCode ) {
	std::string strTemp = "";
	IPurchaseAdapter* driver = reinterpret_cast<ChinaMobileMMPurchaseAdapter*>( nativeObject );
	switch (resultCode) {
	case BILLING_RESULT_SUCCESS:
		AndroidAppDriver::StaticEnqueueCallback( *driver, &IPurchaseAdapter::OnPaymentComplete, strTemp );
		break;
	case BILLING_RESULT_FAILED:
		AndroidAppDriver::StaticEnqueueCallback( *driver, &IPurchaseAdapter::OnPaymentIncomplete, IPurchaseDriver::Error );
		break;
	case BILLING_RESULT_CANCELED:
		AndroidAppDriver::StaticEnqueueCallback( *driver, &IPurchaseAdapter::OnPaymentIncomplete, IPurchaseDriver::Canceled );
		break;
	case BILLING_RESULT_ALREADY_PAID:
		AndroidAppDriver::StaticEnqueueCallback( *driver, &IPurchaseAdapter::OnPaymentIncomplete, IPurchaseDriver::AlreadyPaid );
		break;
	}
}

void ChinaMobileMMPurchaseAdapter::Initialize() {
	IPurchaseAdapter::Initialize();

	__android_log_print( ANDROID_LOG_VERBOSE, "ChinaMobileMMPurchase", "Initialize" );
	JNIEnv* env = Android::Util::GetJNIEnv();
	JavaInitializeSDK( env, mJavaObject );
}

bool ChinaMobileMMPurchaseAdapter::CanPay() {
	return true;
}

void ChinaMobileMMPurchaseAdapter::GetProductCode(const std::string& productId, std::string& productCode) {
	//TODO detail for product
	//productCode = "0211C4300411022177574311022177503101MC099716000000000000000000000000";
	productCode = "123";
}

void ChinaMobileMMPurchaseAdapter::RequestPay(const std::string& productId) {
	IPurchaseAdapter::RequestPay(productId);

	__android_log_print( ANDROID_LOG_VERBOSE, "ChinaMobileMMPurchase", "RequestPay( %s )", productId.c_str() );
	std::string productCode;
	GetProductCode(productId, productCode);

	JNIEnv* env = Android::Util::GetJNIEnv();
	jstring javaProductCode = env->NewStringUTF( productCode.c_str() );
	JavaRequestPay( env, mJavaObject, javaProductCode );
	env->DeleteLocalRef( javaProductCode );
}
