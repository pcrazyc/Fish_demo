#include "TelecomPurchaseAdapter.h"

JavaMethod<void>	TelecomPurchaseAdapter::JavaRequestPay;

TelecomPurchaseAdapter::TelecomPurchaseAdapter() {
	__android_log_print( ANDROID_LOG_INFO, "TelecomPurchaseAdapter", "Let's get retarded!" );

	JNIEnv* env = Android::Util::GetJNIEnv();
	jlong nativeDriver = reinterpret_cast< jlong >( this );
	ConstructJava( env, "com/popcap/purchase/Telecom/TelecomPurchase", "(J)V", this );
}

TelecomPurchaseAdapter::~TelecomPurchaseAdapter() {

}

void TelecomPurchaseAdapter::BindJavaMethods( JNIEnv* env, const JavaClass& javaClass )
{
	JavaRequestPay		.init( env, javaClass, "RequestPay",	"(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V" );
}

void TelecomPurchaseAdapter::BindNativeMethods( JNIEnv* env, const JavaClass& javaClass )
{
	JNINativeMethod methods[] =
	{
		{"FirePaymentComplete",   "(JI)V", (void*)&TelecomPurchaseAdapter::PaymentHook }
	};
	javaClass.registerNatives( methods, LENGTH(methods) );
}

void TelecomPurchaseAdapter::PaymentHook( JNIEnv* env, jobject javaObject, jlong nativeObject, jint resultCode ) {
	__android_log_print( ANDROID_LOG_VERBOSE, "TelecomPurchaseAdapter", "PaymentHook( %d )", resultCode );
	std::string strTemp = "";
	IPurchaseAdapter* driver = reinterpret_cast<TelecomPurchaseAdapter*>( nativeObject );
	switch (resultCode) {
	case BILLING_RESULT_SUCCESS:
		AndroidAppDriver::StaticEnqueueCallback( *driver, &IPurchaseAdapter::OnPaymentComplete, strTemp );
		break;
	case BILLING_RESULT_FAILED:
		AndroidAppDriver::StaticEnqueueCallback( *driver, &IPurchaseAdapter::OnPaymentIncomplete, IPurchaseDriver::Error );
		break;
	case BILLING_RESULT_CANCELED:
		AndroidAppDriver::StaticEnqueueCallback( *driver, &IPurchaseAdapter::OnPaymentIncomplete, IPurchaseDriver::Canceled );
		break;
	case BILLING_RESULT_ALREADY_PAID:
		AndroidAppDriver::StaticEnqueueCallback( *driver, &IPurchaseAdapter::OnPaymentIncomplete, IPurchaseDriver::AlreadyPaid );
		break;
	}
}

bool TelecomPurchaseAdapter::CanPay() {
	return true;
}

void TelecomPurchaseAdapter::GetProductCode(const std::string& productId, std::string& productCode) {
	//TODO detail for product
	productCode = "0211C4300411022177574311022177503101MC099716000000000000000000000000";
}

void TelecomPurchaseAdapter::RequestPay(const std::string& productId) {
	IPurchaseAdapter::RequestPay(productId);

	__android_log_print( ANDROID_LOG_VERBOSE, "TelecomPurchaseAdapter", "RequestPay( %s )", productId.c_str() );
	std::string productCode;
	GetProductCode(productId, productCode);


	std::string feeName = productId;

	JNIEnv* env = Android::Util::GetJNIEnv();
	jstring javaFeeName = env->NewStringUTF( feeName.c_str() );
	jstring javaFeeCode = env->NewStringUTF( productCode.c_str() );
	jstring javaTips = env->NewStringUTF( "test tips" );
	jstring javaOkInfo = env->NewStringUTF( "purchase successful" );
	JavaRequestPay( env, mJavaObject, javaFeeName, javaFeeCode, javaTips, javaOkInfo );
	env->DeleteLocalRef( javaFeeName );
	env->DeleteLocalRef( javaFeeCode );
	env->DeleteLocalRef( javaTips );
	env->DeleteLocalRef( javaOkInfo );
}
