#ifndef CHINAMOBILEMMPURCHASEADAPTER_H_INCLUDED
#define CHINAMOBILEMMPURCHASEADAPTER_H_INCLUDED

#include "drivers/purchase/android/IPurchaseAdapter.h"
#include "drivers/app/android/JavaInterface.h"
#include "drivers/app/android/JavaBound.h"



class ChinaMobileMMPurchaseAdapter : public IPurchaseAdapter, public JavaBound< ChinaMobileMMPurchaseAdapter > {
public:
	ChinaMobileMMPurchaseAdapter();
	~ChinaMobileMMPurchaseAdapter();

	virtual void Initialize();
	// check system or network if can pay
	virtual bool CanPay();

	// request pay for product
	virtual void RequestPay(const std::string& productId);

	void GetProductCode(const std::string& productId, std::string& productCode);
	static void PaymentHook( JNIEnv* env, jobject javaObject, jlong nativeObject, jint resultCode );
private:
	virtual void BindJavaMethods( JNIEnv* env, const JavaClass& javaClass );
	virtual void BindNativeMethods( JNIEnv* env, const JavaClass& javaClass );

	static JavaMethod<void>	JavaInitializeSDK;
	static JavaMethod<void>	JavaRequestPay;


};


#endif
