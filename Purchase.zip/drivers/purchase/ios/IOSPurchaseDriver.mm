
#include "IOSPurchaseDriver.h"

	
IPurchaseDriver* IPurchaseDriver::CreatePurchaseDriver()
{
	return new IOSPurchaseDriver();
}

IOSPurchaseDriver::IOSPurchaseDriver()
{
	
}

IOSPurchaseDriver::~IOSPurchaseDriver()
{
	
}

void IOSPurchaseDriver::SetPaymentMonitor( IPaymentMonitor* monitor )
{
	mPaymentMonitor = monitor;
}

void IOSPurchaseDriver::Refresh( const StructuredData* productIds, RefreshCallback callback )
{
	mRefreshCallback = callback;
	
	//TODO Implementation
}

bool IOSPurchaseDriver::CanMakePayments()
{
	//TODO Implementation
}

bool IOSPurchaseDriver::GetProduct( const std::string& productId, Product* product )
{
	//TODO Implementation
}


void IOSPurchaseDriver::RequestPayment( const std::string& productId )
{
	//TODO Implementation
}

void IOSPurchaseDriver::RestorePurchases( RestoreCallback callback )
{
	//TODO Implementation
}

void IOSPurchaseDriver::ConfirmDelivery( const std::string& receiptId )
{
	//TODO Implementation
}

void IOSPurchaseDriver::ProductsRequestDidReceiveResponse( SKProductsResponse* response )
{
	//TODO Implementation
}

void IOSPurchaseDriver::RequestDidFailWithError( NSError* error )
{
	//TODO Implementation
}

void IOSPurchaseDriver::PaymentQueueUpdatedTransactions( SKPaymentQueue* queue, NSArray* transactions )
{
	//TODO Implementation
}

void IOSPurchaseDriver::PaymentQueueRemovedTransactions( SKPaymentQueue* queue, NSArray* transactions )
{
	//TODO Implementation
}

void IOSPurchaseDriver::PaymentQueueRestoreCompletedTransactionsFailedWithError( SKPaymentQueue* queue, NSError* error )
{
	//TODO Implementation
}

void IOSPurchaseDriver::PaymentQueueRestoreCompletedTransactionsFinished( SKPaymentQueue* queue )
{
	//TODO Implementation
}
