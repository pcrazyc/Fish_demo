
#ifndef IOS_PURCHASE_DRIVER_H_INCLUDED
#define IOS_PURCHASE_DRIVER_H_INCLUDED

#include "IPurchaseDriver.h"
#import <StoreKit/StoreKit.h>


class IOSPurchaseDriver : public IPurchaseDriver
{
public:
	
	IOSPurchaseDriver();
	~IOSPurchaseDriver();

	void SetPaymentMonitor( IPaymentMonitor* monitor );
	void Refresh( const StructuredData* productIds, RefreshCallback callback );
	bool CanMakePayments() ;
	bool GetProduct( const std::string& productId, Product* product );
	void RequestPayment( const std::string& productId );
	void RestorePurchases( RestoreCallback callback );
	void ConfirmDelivery( const std::string& receiptId );
	
	void ProductsRequestDidReceiveResponse( SKProductsResponse* response );
	void RequestDidFailWithError( NSError* error );
	void PaymentQueueUpdatedTransactions( SKPaymentQueue* queue, NSArray* transactions );
	void PaymentQueueRemovedTransactions( SKPaymentQueue* queue, NSArray* transactions );
	void PaymentQueueRestoreCompletedTransactionsFailedWithError( SKPaymentQueue* queue, NSError* error );
	void PaymentQueueRestoreCompletedTransactionsFinished( SKPaymentQueue* queue );
	
protected:
	IPaymentMonitor* mPaymentMonitor;
};		

