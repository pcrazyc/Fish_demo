#include "AndroidPurchaseDriver.h"
#include "StructuredData.h"
#include "IPurchaseAdapter.h"

IPurchaseDriver* IPurchaseDriver::CreatePurchaseDriver()
{
	return new AndroidPurchaseDriver();
}

AndroidPurchaseDriver::AndroidPurchaseDriver()
{
	mPurchaseAdapter = 0;
}

AndroidPurchaseDriver::~AndroidPurchaseDriver()
{
	if (mPurchaseAdapter) {
		delete mPurchaseAdapter;
		mPurchaseAdapter = 0;
	}
}

void AndroidPurchaseDriver::SetPurchaseAdapter(IPurchaseAdapter *purchaseAdapter) {
	mPurchaseAdapter = purchaseAdapter;
	mPurchaseAdapter->SetPurchaseDriver(this);
}

void AndroidPurchaseDriver::Init() {
	if (mPurchaseAdapter) mPurchaseAdapter->Initialize();
}

void AndroidPurchaseDriver::SetPaymentMonitor( IPaymentMonitor* monitor )
{
	mPaymentMonitor = monitor;
}

void AndroidPurchaseDriver::Refresh( const StructuredData* productIds, RefreshCallback callback )
{
	mRefreshCallback = callback;
}

bool AndroidPurchaseDriver::CanMakePayments()
{
	if (!mPurchaseAdapter) return false;

	return mPurchaseAdapter->CanPay();
}

bool AndroidPurchaseDriver::HasCatalogData()
{
	return false;
}

bool AndroidPurchaseDriver::GetProduct( const std::string& productId, Product* product )
{
	return false;
}

bool AndroidPurchaseDriver::ProductTypeIsSupported( ProductType prodType )
{
	return true;
}

void AndroidPurchaseDriver::RequestPayment( const std::string& productId )
{
	if (mPurchaseAdapter) mPurchaseAdapter->RequestPay(productId);
}

void AndroidPurchaseDriver::RestorePurchases( RestoreCallback callback )
{
	mRestoreCallback = callback;
}

void AndroidPurchaseDriver::ConfirmDelivery( const std::string& receiptId )
{
}

bool AndroidPurchaseDriver::HasUnconfirmedPayments()
{
	return false;
}

void AndroidPurchaseDriver::OnPaymentComplete( const std::string& receiptId, const std::string& receipt )
{
	if ( mPaymentMonitor )
	{
		mPaymentMonitor->PurchaseDriverPaymentComplete( this, receiptId, receipt );
	}
}

void AndroidPurchaseDriver::OnPaymentIncomplete( const std::string& productId, const IPurchaseDriver::CauseForIncompletion& cause )
{
	if ( mPaymentMonitor )
	{
		mPaymentMonitor->PurchaseDriverPaymentIncomplete( this, productId, cause );
	}
}
