#include "IPurchaseAdapter.h"

IPurchaseAdapter::IPurchaseAdapter() {
	Initialize();
}

IPurchaseAdapter::~IPurchaseAdapter() {

}

void IPurchaseAdapter::Initialize() {
	mProductId = "";
	mPurchaseDriver = 0;
}

void IPurchaseAdapter::SetPurchaseDriver( AndroidPurchaseDriver* purchaseDriver ) {
	mPurchaseDriver = purchaseDriver;
}

void IPurchaseAdapter::RequestPay(const std::string& productId) {
	mProductId = productId;
}

void IPurchaseAdapter::OnPaymentComplete( const std::string& receipt ) {
	if (mPurchaseDriver) mPurchaseDriver->OnPaymentComplete(mProductId, receipt);
}

void IPurchaseAdapter::OnPaymentIncomplete( const IPurchaseDriver::CauseForIncompletion& cause ) {
	if (mPurchaseDriver) mPurchaseDriver->OnPaymentIncomplete(mProductId, cause);
}
