#ifndef PURCHASE_ADAPTER_H_INCLUDED
#define PURCHASE_ADAPTER_H_INCLUDED

#include "AndroidPurchaseDriver.h"
#include "drivers/app/android/JavaBound.h"
#include "drivers/app/android/AndroidAppDriver.h"
#include <list>


class IPurchaseAdapter {
public:
	struct ProductInfo {
		std::string productIdentifier;
		std::string localizedDescription;
		std::string localizedTitle;
		std::string localizedPrice;
	};

	enum ResultCode {
		BILLING_RESULT_SUCCESS = 0,
		BILLING_RESULT_FAILED,
		BILLING_RESULT_CANCELED,
		BILLING_RESULT_ALREADY_PAID
	};

	IPurchaseAdapter();
	virtual ~IPurchaseAdapter();
	// check system or network if can pay
	virtual bool CanPay() = 0;

	// Initialize sdk or some configure
	virtual void Initialize();

	// request pay for product
	virtual void RequestPay(const std::string& productId);

	virtual void SetPurchaseDriver( AndroidPurchaseDriver* purchaseDriver );

	virtual void OnPaymentComplete( const std::string& receipt );
	virtual void OnPaymentIncomplete( const IPurchaseDriver::CauseForIncompletion& cause );

protected:
	AndroidPurchaseDriver *mPurchaseDriver;
	std::string mProductId;

};

#endif
