#ifndef ANDROID_PURCHASE_DRIVER_H_INCLUDED
#define ANDROID_PURCHASE_DRIVER_H_INCLUDED

#include "IPurchaseDriver.h"

class IPurchaseAdapter;

class AndroidPurchaseDriver : public IPurchaseDriver 	{
public:
	AndroidPurchaseDriver();
	virtual ~AndroidPurchaseDriver();

	virtual void SetPaymentMonitor( IPaymentMonitor* monitor );
	virtual void Refresh(  const StructuredData* productIds, RefreshCallback callback );
	virtual bool CanMakePayments();
	virtual bool HasCatalogData();
	virtual bool GetProduct( const std::string& productId, Product* product );
	virtual bool ProductTypeIsSupported( ProductType prodType );
	virtual void RequestPayment( const std::string& productId );
	virtual void RestorePurchases( RestoreCallback callback );
	virtual void ConfirmDelivery( const std::string& receiptId );
	virtual bool HasUnconfirmedPayments();

	void OnPaymentComplete( const std::string& receiptId, const std::string& receipt );
	void OnPaymentIncomplete( const std::string& productId, const IPurchaseDriver::CauseForIncompletion& cause );

	void SetPurchaseAdapter(IPurchaseAdapter *purchaseAdapter);
	void Init();

private:
	IPaymentMonitor* mPaymentMonitor;
	IPurchaseAdapter *mPurchaseAdapter;

	RefreshCallback mRefreshCallback;
	RestoreCallback mRestoreCallback;
};

#endif
