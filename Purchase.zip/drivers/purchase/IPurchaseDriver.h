#ifndef PURCHASE_DRIVER_H_INCLUDED
#define PURCHASE_DRIVER_H_INCLUDED

#include "Common.h"
#include <string>
#include <vector>
#include <map>

class StructuredData;
class IPaymentMonitor;

class IPurchaseDriver
{
public:
	
	static IPurchaseDriver* CreatePurchaseDriver();
	
	enum ProductType
	{
		Consumable,
		Restorable,
		Subscription,
	};
	
	enum CauseForIncompletion
	{
		Error,
		Canceled,
		UserNotAuthorized,
		ServiceUnavailable,
		AlreadyPaid
	};
	
	struct Product
	{
		std::string productIdentifier;
		std::string localizedDescription;
		std::string localizedTitle;
		std::string localizedPrice;
	};
	
	typedef Delegate1<IPurchaseDriver*> RefreshCallback;
	typedef Delegate2<IPurchaseDriver*,bool> RestoreCallback;
	
	virtual ~IPurchaseDriver() {}

	virtual void SetPaymentMonitor( IPaymentMonitor* monitor ) = 0;
	virtual void Refresh( const StructuredData* productIds, RefreshCallback callback ) = 0;
	virtual bool CanMakePayments() = 0;
	
	virtual bool GetProduct( const std::string& productId, Product* product ) = 0;
	virtual void RequestPayment( const std::string& productId ) = 0;
	virtual void RestorePurchases( RestoreCallback callback ) = 0;
	virtual void ConfirmDelivery( const std::string& receiptId ) = 0;		
};

class IPaymentMonitor
{
public:
	virtual void PurchaseDriverPaymentComplete( IPurchaseDriver* merch, const std::string& receiptId, const std::string& receipt ) = 0;
	virtual void PurchaseDriverPaymentIncomplete( IPurchaseDriver* merch, const std::string& productId, IPurchaseDriver::CauseForIncompletion ) = 0;
};

